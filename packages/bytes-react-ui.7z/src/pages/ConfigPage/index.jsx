const ConfigPage = () => {
  return(
    <div>
      config
    </div>
  )
}

export default ConfigPage
