const AboutPage = () => {
  return <div> About </div>
}

export default AboutPage
