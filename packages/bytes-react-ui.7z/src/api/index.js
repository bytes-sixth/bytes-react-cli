const api = 'this is api'

export default api
