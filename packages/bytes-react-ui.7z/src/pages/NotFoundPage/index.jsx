// 404 not found page
// 提供信息提示，返回主页接口

const NotFoundPage = () => {
  return <div> 404 Not Found </div>
}

export default NotFoundPage
