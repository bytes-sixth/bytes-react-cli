import Mock from 'mockjs'

export default Mock.mock({
  status: 200,
  'dataSource|1-9': [
    {
      'key|+1': 1,
      'mockTitle|1': ['原来如此'],
    },
  ],
})
