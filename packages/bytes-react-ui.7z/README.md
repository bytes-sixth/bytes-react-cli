# bytes-react-cli

## 下载

```sh
git clone https://github.com/bytes-sixth/bytes-react-cli.git
```

## 安装依赖

```sh
cd bytes-react-cli/packages/bytes-react-ui
yarn
```

## 开发运行

```sh
yarn dev
```

打开 http://localhost:3000 查看

## 编译

```sh
yarn build
```

## TODO

- [ ] favicon 图标
- [ ] 请求服务器
- [ ] 轮询是否结束,结束时,关闭窗口
