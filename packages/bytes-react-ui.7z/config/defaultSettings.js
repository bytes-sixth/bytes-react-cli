const Settings = {
  title: 'bytes sixth ui',
}

export default Settings
