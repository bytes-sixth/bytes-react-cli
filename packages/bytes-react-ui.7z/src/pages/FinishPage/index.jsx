const FinishPage = {}

export default FinishPage
